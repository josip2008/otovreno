<?php

	mb_internal_encoding("UTF-8");
	error_reporting( E_ALL );
	function trazi()
	{
		$array = array();

		if (!empty($_REQUEST['ime_kluba'])){	
			$array[] = 'contains(' . 'ime_kluba' . ', "' .$_REQUEST['ime_kluba'] . '")';
		}
		if (!empty($_REQUEST['drzava'])){
			$array[] = 'contains(' . 'drzava' . ', "' . $_REQUEST['drzava'] . '")';
		}
		if (!empty($_REQUEST['godina'])){
			$array[] = 'contains(godina_osnivanja, "'.$_REQUEST['godina'].'")';
		}

		$trener = array();
			if (!empty($_REQUEST['ime_trenera'])){
				$trener[] = 'contains(' . 'ime_trenera' . ', "' . $_REQUEST['ime_trenera'] . '")';
			}
			if (!empty($_REQUEST['prezime_trenera'])){
				$trener[] = 'contains(' . 'prezime_trenera' . ', "' . $_REQUEST['prezime_trenera'] . '")';
			}
			if (!empty($_REQUEST['uloga'])){
				$var = implode ("",$_REQUEST['uloga']);
				if(!empty($_REQUEST['ime_trenera']) or !empty($_REQUEST['prezime_trenera']))
				{$trener[] = '@uloga="' . $var . '"';}
				else 
				{$trener[] = '@uloga="' . $var . '"';}
			}
		if(!empty($trener))
			{$array[] = 'trener[' . implode(' and ', $trener) . ']';}	

		$stadion=array();
			if (!empty($_REQUEST['ime_stadiona'])){
				$stadion[] = 'contains(' . 'ime_stadiona' . ', "' . $_REQUEST['ime_stadiona'] . '")';
			}
			if (!empty($_REQUEST['kapacitet'])){
				$stadion[] = 'contains(kapacitet, "'.$_REQUEST['kapacitet'].'")';
			}
			if (!empty($_REQUEST['godina_izgradnje'])){
				$stadion[] = 'contains(godina_izgradnje, "'.$_REQUEST['godina_izgradnje'].'")';
			}
			if (!empty($_REQUEST['adresa'])){
				$stadion[] = 'contains(' . 'adresa' . ', "' . $_REQUEST['adresa'] . '")';
			}
			if(!empty($_REQUEST['pbr'])){
				$pbr = array();
				$pbr[] = '@postanski_broj="' . $_REQUEST['pbr'].'"';
				$stadion[] = 'adresa[' . implode(' ', $pbr) . ']';
				}
		if(!empty($stadion))
			{$array[] = 'stadion[' . implode(' and ', $stadion) . ']';}

		if (!empty($_REQUEST['mail'])){
			$array[] = 'contains(' . 'mail_adresa' . ', "' . $_REQUEST['mail'] . '")';
		}

		if (!empty($_REQUEST['kategorija']))
		{	$kate = array();			
			foreach ($_REQUEST['kategorija'] as $kategorija)
				{$kate[] = 'navijaci="' . $kategorija . '"';}			
			if (!empty($kate))
			{$array[] = '(' . implode(' or ', $kate) . ')';}
		}

		$igrac=array();
			if (!empty($_REQUEST['imeIgrača'])){
				$igrac[] = 'contains(' . 'ime' . ', "' . $_REQUEST['imeIgrača'] . '")';
			}

			if (!empty($_REQUEST['prezimeIgrača'])){
				$igrac[] = 'contains(' . 'prezime' . ', "' . $_REQUEST['prezimeIgrača'] . '")';
			}

			if (!empty($_REQUEST['pozicija']))
			{	$posi = array();			
				foreach ($_REQUEST['pozicija'] as $pozicija)
				{$posi[] = 'pozicija="' . $pozicija . '"';}			
				if (!empty($posi))
				{	if(!empty($_REQUEST['imeIgrača']) or !empty($_REQUEST['prezimeIgrača']))
					{$igrac[] = '' . implode(' or ', $posi) . '';}
					else
					{$igrac[] = '' . implode(' or ', $posi) . '';}
				}
			}
		if(!empty($igrac))
			{$array[] = 'kljucni_igrac[' . implode(' and ', $igrac) . ']';}	

		$preetyfy = implode(' and ', $array);
		if (!empty($preetyfy))
		{return '/podaci/sudionik['. $preetyfy .']';}
		else
		{return '/podaci/sudionik';}
	}

?>