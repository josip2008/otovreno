<?php
  include ('funkcije.php');
  error_reporting (E_ALL);
  $dom = new DOMDocument();
  $dom->load('podaci.xml');
  $xp = new DOMXPath($dom);
  $upit = trazi();
  $rezultat = $xp->query($upit);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Ovo je naslov stranice</title>
  <link rel="stylesheet" type="text/css" href="dizajn.css">
</head>

<body>

<div class="wrapper">

  <div id="header">
    <h1>Euroleague</h1>
  </div>

  <div id="nav">
    <img id="slike" src="slike/EuroleagueLogo.png" alt="Euroleague Logo">
      <ul>
        <li>
          <a href="index.html">Početna</a></li>
        <li>
          <a href="obrazac.html">Pretraživanje</a></li>
        <li>
          <a href="http://www.fer.unizg.hr/predmet/or">Link na OR</a></li>
        <li>
          <a href="http://www.fer.unizg.hr" target="_blank">Link na FER</a></li>
        <li>
          <a class="link" href="mailto:josip.zuljevic@fer.hr">Kontakt e-mail</a></li>
        <li>
          <a href="podaci.xml">Podaci iz xml-a</a></li>
      </ul>
  </div>


 <table id="query_table">
  <tr>
    <th>
      Ime Kluba
    </th>
    <th>
      Država
    </th>
    <th>
      Godina osnivanja
    </th>
    <th>
      Trener i uloga
    </th>
    <th>
      Stadion
    </th>
    <th>
      Ključni igrač
    </th>
  </tr>
<?php foreach ($rezultat as $reza) {
?>
  <tr>
    <td> 
    <?php
    $drugi = $reza;
    echo $drugi->getElementsByTagName('ime_kluba')->item(0)->nodeValue;
    ?>  
   </td>
    <td>    
    <?php
    echo $drugi->getElementsByTagName('drzava')->item(0)->nodeValue;
    ?> 
    </td>
        <td> 
    <?php
    echo $drugi->getElementsByTagName('godina_osnivanja')->item(0)->nodeValue;
    ?>  
   </td>
    <td>    
    <?php
    echo $drugi->getElementsByTagName('ime_trenera')->item(0)->nodeValue;
    echo " ";
    echo $drugi->getElementsByTagName('prezime_trenera')->item(0)->nodeValue;
    echo ", ";
    $attr=$drugi->getElementsByTagName('trener')->item(0)->getAttribute('uloga');
    echo $attr;
    ?> 
    </td>
    <td> 
    <?php
    echo $drugi->getElementsByTagName('ime_stadiona')->item(0)->nodeValue;
    ?>  
   </td>
    <td>    
    <?php
    echo $drugi->getElementsByTagName('ime')->item(0)->nodeValue ; 
    echo " ";
    echo $drugi->getElementsByTagName('prezime')->item(0)->nodeValue; 
    echo ", ";
    echo $drugi->getElementsByTagName('pozicija')->item(0)->nodeValue; 
    ?> 
    </td>
  </tr>
  <?php } ?>
</table>

  </body>
</html>